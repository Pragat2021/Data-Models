import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    // username: String,
    // email:String,
    // isActive:Boolean
    username: {
      type: String,
      required: true,
      unique: true,
      lowecase: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowecase: true,
    },
    password: {
      type: String,
      required: true,
      unique: true,
    },
  },
  { timestamp: true }
);

export const User = mongoose.model('User', userSchema);

// users  in mongoDB means in database mongoDB makes it plural
