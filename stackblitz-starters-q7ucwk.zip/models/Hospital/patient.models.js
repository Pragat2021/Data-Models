import mongoose from 'mongoose';

const patientSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      lowecase: true,
    },
    age: {
      type: Number,
      required: true,
    },
    disease: {
      type: String,
      lowercase: true,
      required: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Patient',
      required: true,
    },
    status: {
      type: String,
      required: true,
    },
    bill: {
      type: String,
      required: true,
      lowercase: true,
    },
    arrival: [
      {
        type: String,
        required: true,
      },
    ],
  doctor:{
    type:mongoose.Schema.Types.ObjectId,
    ref="Doctor"
  },
},
  { timestamp: true }
);

export const Patient = mongoose.model('Patient', patientSchema);
