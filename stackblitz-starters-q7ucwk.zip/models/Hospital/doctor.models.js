import mongoose from 'mongoose';

const doctorSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      unique: true,
    },
    age: {
      type: Number,
      required: true,
      unique: true,
    },
    daysAvailable: {
      type: Date,
      default: Date.now,
    },
    specialization: {
      type: string,
      required: true,
    },
    fees: {
      type: number,
      required: true,
    },
    patient:{
      type:mongoose.Schema.Types.ObjectId,
      ref="Patient"
    }
  },
  { timestamp: true }
);

export const Doctor = mongoose.model('Doctor', doctorSchema);
