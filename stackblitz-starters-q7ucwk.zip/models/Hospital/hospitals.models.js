import mongoose  from 'mongoose'

const hospitalSchema =new mongoose.Schema({
  name:{
    type:String,
    required:true
  },
  oxygenPresent:{
    type:Number,
    unique:true,
    required:true
  },                                       

  doctors:{
    type:mongoose.Schema.Types.ObjectId,
    ref:"Doctor"
  },
  patients:{
    type:mongoose.Schema.Types.ObjectId,
    ref="Patient"
  }
},{timestamp:true})

export const Hospital = mongoose.model("Hospital", hospitalSchema)